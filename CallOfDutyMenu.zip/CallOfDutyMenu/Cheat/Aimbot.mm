//
//  Aimbot.cpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 18/05/2025.
//

#include "Aimbot.hpp"
#include "imgui.h"

// Initialisation des variables statiques
bool Aimbot::isEnabled = false;
int Aimbot::aim_target = 0;
int Aimbot::aim_trigger = 0;
int Aimbot::aim_location = 0;
float Aimbot::tDis = 0.0f;
float Aimbot::tDistance = 0.0f;
float Aimbot::markDistance = FLT_MAX;
float Aimbot::markDis = 0.0f;
Vector3 Aimbot::TargetPos = Vector3(0, 0, 0);
bool Aimbot::needAdjustAim = false;

void Aimbot::Enable() {
    if (!Aimbot::isEnabled) return;
    
    void* localPawn = GameAPI::getLocalPawn();
    NSLog(@"Aimbot::Enable - localPawn: %p", localPawn);
    if (!localPawn) return;
    
    // Vérification des conditions de déclenchement
    if (Aimbot::aim_trigger == 1) {
        if (!GameAPI::isFiring(localPawn)) return;
    } else if (Aimbot::aim_trigger == 2) {
        if (!GameAPI::isAiming(localPawn)) return;
    }
    
    Matrix4x4 viewMatrix = GameAPI::getWorldToCamera();
    Matrix4x4 projectionMatrix = GameAPI::getProjectionMatrixInternal();
    Vector3 localPlayerPosition = GameAPI::getPlayerPosition(localPawn);
    
    void* gameInstance = GameAPI::getGameInstance();
    NSLog(@"Aimbot::Enable - gameInstance: %p", gameInstance);
    if (!gameInstance) return;
    
    NSLog(@"Aimbot::Enable - Adresse de gameInstance + 0x168: %p", (void*)((uint64_t)gameInstance + 0x168));
    monoList<void **> *enemyList = *(monoList<void **>**)((uint64_t)gameInstance + 0x168);
    NSLog(@"Aimbot::Enable - enemyList: %p", enemyList);
    if (!enemyList) return;
    
    float closestDistance = std::numeric_limits<float>::infinity();
    float closestFovDistance = std::numeric_limits<float>::infinity();
    void* bestTarget = nullptr;
    Vector3 bestTargetPosition;
    Vector2 bestScreenPos;
    
    int enemyCount = enemyList->getSize();
    NSLog(@"Aimbot::Enable - Nombre d'ennemis: %d", enemyCount);
    
    for (int i = 0; i < enemyCount; i++) {
        void* enemyPawn = enemyList->getItems()[i];
        NSLog(@"Aimbot::Enable - Ennemi %d: %p", i, enemyPawn);
        if (!enemyPawn) continue;
        if (!GameAPI::isAlive(enemyPawn)) continue;
        
        float health = GameAPI::getHealth(enemyPawn);
        if (health <= 0) continue;
        
        Vector3 enemyPosition = GameAPI::getPlayerPosition(enemyPawn);
        float distance = Vector3::Distance(localPlayerPosition, enemyPosition);
        
        // Correction de l'accès à l'os cible
        uint64_t boneOffset = 0x2F0;
        void* bonePtr = (void*)((uint64_t)enemyPawn + boneOffset);
        NSLog(@"Aimbot::Enable - Adresse de l'os: %p", bonePtr);
        
        if (!bonePtr) {
            NSLog(@"Aimbot::Enable - Pointeur d'os invalide");
            continue;
        }
        
        void* targetBone = *(void**)bonePtr;
        NSLog(@"Aimbot::Enable - targetBone: %p", targetBone);
        if (!targetBone) {
            NSLog(@"Aimbot::Enable - Os cible non trouvé");
            continue;
        }
        
        Vector3 bonePosition = GameAPI::getTransformPositionInternal(targetBone);
        
        // Ajustement de la position de visée selon le paramètre
        if (Aimbot::aim_location == 1) {
            bonePosition.y -= 0.2f; // Poitrine
        } else if (Aimbot::aim_location == 2) {
            bonePosition.y -= 0.4f; // Jambes/ceinture
        }
        
        Vector4 targetPosView = GameAPI::GetViewCoords(bonePosition, viewMatrix);
        Vector4 targetPosClip = GameAPI::GetClipCoords(targetPosView, projectionMatrix);
        
        if (targetPosClip.Z < 0.1f) continue;
        
        Vector3 targetPosNorm = GameAPI::NormalizeCoords(targetPosClip);
        Vector2 targetScreenPos = GameAPI::GetScreenCoords(targetPosNorm);
        
        if (targetScreenPos.X < 0 || targetScreenPos.X > kWidth ||
            targetScreenPos.Y < 0 || targetScreenPos.Y > kHeight) {
            continue;
        }
        
        float centerX = kWidth / 2.0f;
        float centerY = kHeight / 2.0f;
        float dx = targetScreenPos.X - centerX;
        float dy = targetScreenPos.Y - centerY;
        float fovDistance = sqrt(dx * dx + dy * dy);
        
        bool selectTarget = false;
        
        if (Aimbot::aim_target == 0) {
            if (distance < closestDistance) {
                closestDistance = distance;
                selectTarget = true;
            }
        } else if (Aimbot::aim_target == 1) {
            if (fovDistance <= GameAPI::FOVCircleSize) {
                if (fovDistance < closestFovDistance) {
                    closestFovDistance = fovDistance;
                    selectTarget = true;
                }
            }
        }
        
        if (selectTarget) {
            bestTarget = enemyPawn;
            bestTargetPosition = bonePosition;
            closestDistance = distance;
            bestScreenPos = targetScreenPos;
            NSLog(@"Aimbot::Enable - Cible sélectionnée: %p, Distance: %.1f", bestTarget, closestDistance);
        }
    }
    
    if (bestTarget) {
        void* mainCamera = GameAPI::getMainCamera();
        NSLog(@"Aimbot::Enable - mainCamera: %p", mainCamera);
        if (!mainCamera) return;
        
        void* mainView = GameAPI::getComponentTransform(mainCamera);
        NSLog(@"Aimbot::Enable - mainView: %p", mainView);
        if (!mainView) return;
        
        Vector3 cameraPosition = GameAPI::getTransformPositionInternal(mainView);
        Vector3 aimDirection = bestTargetPosition - cameraPosition;
        
        // Calcul de la rotation de visée
        Quaternion targetAim = Quaternion::LookRotation(aimDirection, Vector3::Up());
        
        // Application de la visée
        NSLog(@"Aimbot::Enable - Application de la visée sur la cible: %p", bestTarget);
        GameAPI::setAimPosition(localPawn, targetAim);
    }
}

void Aimbot::Start() {
    NSLog(@"Aimbot::Start - Début");
    NSLog(@"Aimbot::Start - isEnabled: %d", isEnabled);
    
    if (!isEnabled) return;
    
    NSLog(@"Aimbot::Start - getGameInstance: %p", GameAPI::getGameInstance);
    if (!GameAPI::getGameInstance) {
        NSLog(@"Aimbot::Start - getGameInstance est null");
        return;
    }
    
    auto gameInstance = GameAPI::getGameInstance();
    NSLog(@"Aimbot::Start - gameInstance: %p", gameInstance);
    
    if (!gameInstance) {
        NSLog(@"Aimbot::Start - gameInstance est null");
        return;
    }
    
    markDistance = std::numeric_limits<float>::infinity();;
    needAdjustAim = false;
    
    if (isEnabled) {
        NSLog(@"Aimbot activé");
    } else {
        NSLog(@"Aimbot désactivé");
    }
}
