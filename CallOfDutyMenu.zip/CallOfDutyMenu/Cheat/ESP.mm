//
//  ESP.cpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 21/05/2025.
//

#include "ESP.hpp"
#include "imgui.h"

// Initialisation des variables statiques
bool ESP::isEnabled = false;
bool ESP::show_lines = false;
bool ESP::show_boxes = false;
bool ESP::show_info = false;
int ESP::distance_value = 200;
float ESP::color[4] = {1.0f, 0.0f, 0.0f, 1.0f};
float ESP::tDistance = 0.0f;
float ESP::markDistance = FLT_MAX;
bool ESP::needAdjustAim = false;
Vector3 ESP::TargetPos = Vector3(0, 0, 0);
ImFont* ESP::_espFont = nullptr;

void ESP::Initialize() {
    ImGuiIO& io = ImGui::GetIO();
    _espFont = io.Fonts->AddFontDefault();
    NSLog(@"ESP::Initialize - _espFont: %p", _espFont);
}

void ESP::Enable() {
    if (!ESP::isEnabled) return;
    
    NSLog(@"ESP::Enable - Début");
    NSLog(@"ESP::Enable - getGameInstance: %p", GameAPI::getGameInstance);
    
    if (!GameAPI::getGameInstance) {
        NSLog(@"ESP::Enable - getGameInstance est null");
        return;
    }
    
    auto gameInstance = GameAPI::getGameInstance();
    NSLog(@"ESP::Enable - gameInstance: %p", gameInstance);
    
    if (!gameInstance) {
        NSLog(@"ESP::Enable - gameInstance est null");
        return;
    }
    
    Matrix4x4 viewMatrix = GameAPI::getWorldToCamera();
    Matrix4x4 projectionMatrix = GameAPI::getProjectionMatrixInternal();
    
    NSLog(@"ESP::Enable - Adresse de gameInstance + 0x158: %p", (void*)((uint64_t)gameInstance + 0x168));
    monoList<void **> *enemyList = *(monoList<void **>**)((uint64_t)gameInstance + 0x168);
    NSLog(@"ESP::Enable - enemyList: %p", enemyList);
    
    if (!enemyList) {
        NSLog(@"ESP::Enable - enemyList est null");
        return;
    }
    
    int enemyCount = enemyList->getSize();
    NSLog(@"ESP::Enable - Nombre d'ennemis: %d", enemyCount);
    
    for (int i = 0; i < enemyCount; i++) {
        void* enemy = enemyList->getItems()[i];
        NSLog(@"ESP::Enable - Ennemi %d: %p", i, enemy);
        
        if (!enemy) {
            NSLog(@"ESP::Enable - Ennemi %d est null", i);
            continue;
        }
        
        NSLog(@"ESP::Enable - Adresse de enemy + 0x590: %p", (void*)((uint64_t)enemy + 0x590));
        void* enemyInfo = *(void **)((uint64_t)enemy + 0x590);
        NSLog(@"ESP::Enable - enemyInfo: %p", enemyInfo);
        
        if (!enemyInfo) {
            NSLog(@"ESP::Enable - enemyInfo est null");
            continue;
        }
        
        Vector3 enemyPositionWorld = GameAPI::getPlayerPosition(enemy);
        Vector4 enemyPositionView = GameAPI::GetViewCoords(enemyPositionWorld, viewMatrix);
        Vector4 enemyPositionClip = GameAPI::GetClipCoords(enemyPositionView, projectionMatrix);
        Vector3 enemyPositionNormalized = GameAPI::NormalizeCoords(enemyPositionClip);
        Vector2 enemyPositionScreen = GameAPI::GetScreenCoords(enemyPositionNormalized);
        
        void* headBone = *(void **)((uint64_t)enemy + 0x2F0);
        if (!headBone) continue;
        
        Vector3 enemyHeadPositionWorld = GameAPI::getTransformPositionInternal(headBone);
        Vector4 enemyHeadPositionView = GameAPI::GetViewCoords(enemyHeadPositionWorld, viewMatrix);
        Vector4 enemyHeadPositionClip = GameAPI::GetClipCoords(enemyHeadPositionView, projectionMatrix);
        enemyHeadPositionClip.Y += 0.5f;
        Vector3 enemyHeadPositionNormalized = GameAPI::NormalizeCoords(enemyHeadPositionClip);
        Vector2 enemyHeadPositionScreen = GameAPI::GetScreenCoords(enemyHeadPositionNormalized);
        
        if (GameAPI::GetInsideFov(kWidth, kHeight, enemyHeadPositionScreen, GameAPI::FOVCircleSize)) {
            tDistance = GameAPI::GetCenterOffsetForVector(enemyHeadPositionScreen, Vector2(kWidth, kHeight));
            if (tDistance <= GameAPI::FOVCircleSize && tDistance < markDistance) {
                needAdjustAim = true;
                if (needAdjustAim) {
                    markDistance = tDistance;
                    TargetPos = enemyHeadPositionWorld;
                }
            }
        }
        
        bool isFacing = (enemyPositionClip.Z >= 0.01f);
        bool isVisible = (enemyPositionScreen.X >= 0 && enemyPositionScreen.X <= kWidth);
        
        if (isVisible && isFacing) {
            Vector3 localPlayerPosition = Vector3(0, 0, 0);
            if (GameAPI::getLocalPawn) {
                localPlayerPosition = GameAPI::getPlayerPosition(GameAPI::getLocalPawn());
            }
            
            float distance = Vector3::Distance(localPlayerPosition, enemyPositionWorld);
            bool shouldShow = distance_value >= distance;
            
            bool isAlive = false;
            if (GameAPI::isAlive) {
                isAlive = GameAPI::isAlive(enemy);
            }
            if (!isAlive) continue;
            
            if (show_lines && isAlive) {
                if (show_info) {
                    RenderLine(ImVec2(kWidth / 2, 0), ImVec2(enemyHeadPositionScreen.X, enemyHeadPositionScreen.Y - 20),
                            ImColor(color[0], color[1], color[2]), 0.9);
                } else {
                    RenderLine(ImVec2(kWidth / 2, 0), ImVec2(enemyHeadPositionScreen.X, enemyHeadPositionScreen.Y),
                            ImColor(color[0], color[1], color[2]), 0.9);
                }
            }
            
            if (show_info && shouldShow && isAlive) {
                float health = 0.0f;
                float maxHealth = 0.0f;
                if (GameAPI::getHealth) {
                    health = GameAPI::getHealth(enemy);
                }
                
                void* attackableInfo = *(void **)((uint64_t)enemy + 0x78);
                if (attackableInfo) {
                    maxHealth = *(float *)((uint64_t)attackableInfo + 0x38);
                }
                
                DrawHealthBar(health, maxHealth, enemyHeadPositionScreen.X, enemyHeadPositionScreen.Y);
            }
            
            if (show_boxes && shouldShow && isAlive) {
                float height = abs(enemyPositionScreen.Y - enemyHeadPositionScreen.Y);
                float width = height * 0.65f;
                DrawBox(enemyHeadPositionScreen.X - (width * 0.5f), enemyHeadPositionScreen.Y,
                        width, height, ImColor(color[0], color[1], color[2]), 0.9, 0.9);
            }
        }
    }
}

void ESP::DrawFOVCircle(float size, ImColor color) {
    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    ImVec2 center(kWidth / 2, kHeight / 2);
    drawList->AddCircle(center, size, color, 100, 3.0f);
}

void ESP::Start() {
    NSLog(@"ESP::Start() - isEnabled: %d", isEnabled);
    
    // Réinitialiser les variables d'état
    markDistance = FLT_MAX;
    needAdjustAim = false;
    
    if (isEnabled) {
        Enable();
    }
}

// Implémentation des fonctions de rendu
void ESP::RenderLine(const ImVec2& start, const ImVec2& end, ImColor color, float thickness) {
    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    drawList->AddLine(start, end, color, thickness);
}

void ESP::DrawText2(ImFont* font, float size, const ImVec2& pos, ImColor textColor, const char* text, ImColor shadowColor) {
    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    drawList->AddText(font, size, ImVec2(pos.x + 1, pos.y + 1), shadowColor, text);
    drawList->AddText(font, size, pos, textColor, text);
}

void ESP::DrawBox(float x, float y, float width, float height, ImColor color, float thickness, float rounding) {
    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    drawList->AddRect(ImVec2(x, y), ImVec2(x + width, y + height), color, rounding, 0, thickness);
}

void ESP::DrawHealthBar(float health, float maxHealth, float x, float y) {
    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    float healthPercent = health / maxHealth;
    float barWidth = 30.0f;
    float barHeight = 4.0f;
    
    // Fond de la barre de vie
    drawList->AddRectFilled(
        ImVec2(x - barWidth/2, y + 5),
        ImVec2(x + barWidth/2, y + 5 + barHeight),
        ImColor(0, 0, 0, 180)
    );
    
    // Barre de vie
    drawList->AddRectFilled(
        ImVec2(x - barWidth/2, y + 5),
        ImVec2(x - barWidth/2 + (barWidth * healthPercent), y + 5 + barHeight),
        ImColor(0, 255, 0, 255)
    );
} 
