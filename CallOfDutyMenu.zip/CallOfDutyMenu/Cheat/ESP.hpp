#ifndef ESP_hpp
#define ESP_hpp

#include <stdio.h>
#include <Foundation/Foundation.h>
#include "GameAPI.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "../lib/UnityStructs/Vector2.h"
#include "../lib/UnityStructs/Vector3.h"
#include "../lib/UnityStructs/Vector4.h"

class ESP {
public:
    static void Enable();
    static void Start();
    static void Initialize();
    
    // Variables statiques
    static bool isEnabled;
    static bool show_lines;
    static bool show_boxes;
    static bool show_info;
    static int distance_value;
    static float color[4];
    
    // Variables pour le rendu
    static float tDistance;
    static float markDistance;
    static bool needAdjustAim;
    static Vector3 TargetPos;
    static ImFont* _espFont;
    
    // Fonctions de rendu
    static void RenderLine(const ImVec2& start, const ImVec2& end, ImColor color, float thickness);
    static void DrawText2(ImFont* font, float size, const ImVec2& pos, ImColor textColor, const char* text, ImColor shadowColor);
    static void DrawBox(float x, float y, float width, float height, ImColor color, float thickness, float rounding);
    static void DrawHealthBar(float health, float maxHealth, float x, float y);
    
    // Fonction pour dessiner le cercle FOV
    static void DrawFOVCircle(float size, ImColor color);
};

#endif /* ESP_hpp */ 
 