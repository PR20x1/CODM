//
//  GameAPI.h
//  CallOfDutyMenu
//
//  Created by Ts1 on 18/05/2025.
//

#ifndef GameAPI_h
#define GameAPI_h

#include "../lib/UnityStructs/Matrix4x4.h"
#include "../lib/UnityStructs/Quaternion.hpp"
#include "../lib/UnityStructs/Unity.hpp"

#include "../lib/UnityStructs/Vector2.h"
#include "../lib/UnityStructs/Vector3.h"
#include "../lib/UnityStructs/Vector4.h"

#include "../Utilities/Macros.h"
#include "imgui.h"
#include <Foundation/Foundation.h>

class GameAPI {
public:
    // Camera Function
    static void Initialize();
    static void* (*getMainCamera)();
    static Matrix4x4 (*getWorldToCameraMatrix)(void* camera);
    static Matrix4x4 (*getProjectionMatrix)(void* camera);
    
    // Component Function
    
    static void* (*getComponentTransform)(void* component);
    
    // Transform Function
    
    static void (*getTransformPosition)(void* transform, Vector3* out);
    static void (*getTransformLocalPosition)(void* transform, Vector3* out);
    
    // Pawn Function
    
    static bool (*isAlive)(void* info);
    static float (*getHealth)(void* Pawn);
    static void (*setAimPosition)(void*, Quaternion);
    static bool (*isAiming)(void* info);
    
    // GamePlay Function
    
    static void* (*getGameInstance)();
    static void* (*getLocalPawn)();
    
    // PlayerInfo Function
    
    static bool (*isRobot)(void* info);
    
    // Drive Handle Function
    
    static bool (*isFiring)(void* info);
    
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

    static Vector3 getPlayerPosition(void* Player);
    static Vector3 getTransformPositionInternal(void* Transform);
    static Vector3 getPlayerLocalPosition(void* Player);
    static Vector3 NormalizeCoords(Vector4 pos);
    
    static Matrix4x4 getWorldToCamera();
    static Matrix4x4 getProjectionMatrixInternal();
    
    static Vector4 GetViewCoords(Vector3 pos, Matrix4x4 modelViewMatrix);
    static Vector4 GetClipCoords(Vector4 pos, Matrix4x4 projectionMatrix);
    
    static Vector2 GetScreenCoords(Vector3 pos);
    
    static NSString *GetEnemyName(float distance, void *enemyInfo);
    
    static bool GetInsideFov(float ScreenWidth, float ScreenHeight, Vector2 PlayerBone, float FovRadius);
    
    static int GetCenterOffsetForVector(Vector2 point, Vector2 CanvasSize);
    
    static float FOVCircleSize;
    static ImVec4 FOVCircleColor;

    static void SetFOVCircleSize(float size);
    static float GetFOVCircleSize();
    static void SetFOVCircleColor(const ImVec4& color);
    static ImVec4 GetFOVCircleColor();

    // FOV Circle functions
    static void DrawFOVCircle(float screenWidth, float screenHeight, float radius, ImU32 color = IM_COL32(255, 0, 0, 255));
    static bool IsPointInFOVCircle(float screenWidth, float screenHeight, Vector2 point, float radius);
};

#endif /* GameAPI_h */
