#include "CheatState.hpp"
 
namespace CheatState {
    bool enable_circleFov = true;
    float circleSizeValue = 100.0f;
} 