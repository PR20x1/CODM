#import "Utilities/Macros.h"
// Custom tap gesture recognizer class
@interface InheritGesture : UITapGestureRecognizer
    @property (nonatomic) int number;
    @property (nonatomic) NSString *text;
    @property (nonatomic) void (*ptr)(); // Pointer to a function
@end
@implementation InheritGesture
@end
@implementation ModController
// Static variables to keep track of enemy data and aim adjustments
static int totalEnemies = 0;
static float tDis = 0, tDistance = 0, markDistance, markDis;
Vector3 TargetPos;
static bool needAdjustAim = false;
static Vector2 markScreenPos;
// Function pointers to obtain various game components
void *(*GetMainCamera)() = (void *(*)())getRealOffset(0x1068EC984); // Camera$$get_main
void *(*GetComponentTransform)(void *component) = (void *(*)(void *))getRealOffset(0x1068F229C); // Component$$get_transform
void (*GetTransformPosition)(void *transform, Vector3 *out) = (void (*)(void *, Vector3 *))getRealOffset(0x106965270); // Transform$$INTERNAL_get_position
void (*GetTransformLocalPosition)(void *transform, Vector3 *out) = (void (*)(void *, Vector3 *))getRealOffset(0x1069652D0); // Transform$$INTERNAL_get_localPosition
bool (*IsAlive)(void *info) = (bool (*)(void *))getRealOffset(0x1010FA510); // Pawn$$get_IsAlive
bool (*IsRobot)(void *info) = (bool (*)(void *))getRealOffset(0x101B67818); // PlayerInfo$$get_IsRobot
float (*GetHealth)(void *pawn) = (float (*)(void*))getRealOffset(0x1010F6998); // Pawn$$get_Health
void* (*getLocalPawn)() = (void *(*)())getRealOffset(0x1018B2624); // Gameplay$$get_LocalPawn
bool (*GetIsFiring)(void *info) = (bool (*)(void *))getRealOffset(0x101962434);
bool (*GetIsAiming)(void *info) = (bool (*)(void *))getRealOffset(0x10110479C);
void* (*getGameInstance)() = (void *(*)())getRealOffset(0x1018A75D8); // Gameplay$$get_Game
void (*setAimRotation)(void*, Quaternion) = (void (*)(void*, Quaternion))getRealOffset(0x10110C8AC); // Pawn$$SetAimRotation
Matrix4x4 (*GetWorldToCameraMatrix)(void* camera) = (Matrix4x4(*)(void*))getRealOffset(0x1068EC298); // Camera$$get_worldToCameraMatrix
Matrix4x4 (*GetProjectionMatrix)(void* camera) = (Matrix4x4(*)(void*))getRealOffset(0x1068EC380); // Camera$$get_projectionMatrixt


// Hooked weapon fire function with adjusted aim logic
bool (*orig_CalWeaponFire)(int64_t a1, Vector3 startPos, Vector3 dir, int64_t a4);
bool CalWeaponFire(int64_t a1, Vector3 startPos, Vector3 dir, int64_t a4) {
    if (YES) {
        float dis = Vector3::Distance(TargetPos, startPos);
        Vector3 delta = TargetPos - startPos;
        Vector3 newDir = delta / dis; // Adjust direction towards target
        return orig_CalWeaponFire(a1, startPos, newDir, a4);
    }
    return orig_CalWeaponFire(a1, startPos, dir, a4);
}
// Get the player's position from their transform component
Vector3 GetPlayerPosition(void *player) {
    Vector3 location;
    GetTransformPosition(GetComponentTransform(player), &location);
    return location;
}
// Get transform's position
Vector3 GetTransformPositionInternal(void *transform) {
    Vector3 location;
    GetTransformPosition(transform, &location);
    return location;
}
Vector3 GetPlayerLocalPosition(void *player) {
    Vector3 location;
    GetTransformLocalPosition(GetComponentTransform(player), &location);
    return location;
}
Matrix4x4 GetWorldToCamera() {
    if (GetMainCamera() != nullptr) {
        return GetWorldToCameraMatrix(GetMainCamera());
    }
    return Matrix4x4(); // Return empty matrix if camera is unavailable
}
Matrix4x4 GetProjectionMatrixInternal() {
    if (GetMainCamera() != nullptr) {
        return GetProjectionMatrix(GetMainCamera());
    }
    return Matrix4x4();
}
// Convert world coordinates to camera view getGameInstance
Vector4 GetViewCoords(Vector3 pos, Matrix4x4 modelViewMatrix) {
    Vector4 viewPos = Vector4(0, 0, 0, 0);
    viewPos.X = pos.x * modelViewMatrix[0][0] + pos.y * modelViewMatrix[1][0] + pos.z * modelViewMatrix[2][0] + modelViewMatrix[3][0];
    viewPos.Y = pos.x * modelViewMatrix[0][1] + pos.y * modelViewMatrix[1][1] + pos.z * modelViewMatrix[2][1] + modelViewMatrix[3][1];
    viewPos.Z = pos.x * modelViewMatrix[0][2] + pos.y * modelViewMatrix[1][2] + pos.z * modelViewMatrix[2][2] + modelViewMatrix[3][2];
    viewPos.W = pos.x * modelViewMatrix[0][3] + pos.y * modelViewMatrix[1][3] + pos.z * modelViewMatrix[2][3] + modelViewMatrix[3][3];
    return viewPos;
}
// Convert camera view coordinates to clip coordinates
Vector4 GetClipCoords(Vector4 pos, Matrix4x4 projectionMatrix) {
    Vector4 clipPos = Vector4(0, 0, 0, 0);
    clipPos.X = pos.X * projectionMatrix[0][0] + pos.Y * projectionMatrix[1][0] + pos.Z * projectionMatrix[2][0] + pos.W * projectionMatrix[3][0];
    clipPos.Y = pos.X * projectionMatrix[0][1] + pos.Y * projectionMatrix[1][1] + pos.Z * projectionMatrix[2][1] + pos.W * projectionMatrix[3][1];
    clipPos.Z = pos.X * projectionMatrix[0][2] + pos.Y * projectionMatrix[1][2] + pos.Z * projectionMatrix[2][2] + pos.W * projectionMatrix[3][2];
    clipPos.W = pos.X * projectionMatrix[0][3] + pos.Y * projectionMatrix[1][3] + pos.Z * projectionMatrix[2][3] + pos.W * projectionMatrix[3][3];
    return clipPos;
}
// Normalize the coordinates by dividing by W
Vector3 NormalizeCoords(Vector4 pos) {
    Vector3 normalized = Vector3(0, 0, 0);
    normalized.x = pos.X / pos.W;
    normalized.y = pos.Y / pos.W;
    normalized.z = pos.Z / pos.W;
    return normalized;
}
// Convert world coordinates to screen coordinates
Vector2 GetScreenCoords(Vector3 pos) {
    Vector2 screen = Vector2(0, 0);
    screen.X = (kWidth / 2.0 * pos.x) + (pos.x + kWidth / 2.0);  // Calculate X screen coordinate
    screen.Y = -(kHeight / 2.0 * pos.y) + (pos.y + kHeight / 2.0);  // Calculate Y screen coordinate
    return screen;
}
// Get enemy name and distance, displaying [AI] for bots
NSString *GetEnemyName(float distance, void *enemyInfo) {
    NSString *dis = [NSString stringWithFormat:@"%d", (int)distance];
    _monoString *m_NickName = *(_monoString **)((uint64_t)enemyInfo + 0x140); // PlayerInfo$$m_NickName
    NSString *nameEnemy = m_NickName->toNSString();
    bool isRobot = IsRobot(enemyInfo);
    if (isRobot || nameEnemy.length == 0) {
        nameEnemy = @"[AI]"; // Default to AI if robot or name is empty
    }
    NSString *nameAndDistance = [NSString stringWithFormat:@"[%@M] %@", dis, nameEnemy];
    return nameAndDistance;
}
static bool MenDeal = true;
ImFont *_espFont;
HeeeNoScreenShotView *noScreenShotView;
UILabel *menuTitle;
// Disable autorotation for this view controller
-(BOOL)shouldAutorotate {
    return NO;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return NO;
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationLandscapeRight;
}
// Initialization method for the ModController, setting up Metal if supported
-(instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];
    if (!self.device) {
        NSLog(@"Metal is not supported");
        abort();
    }
    // Initialize ImGui for creating GUI elements
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io; // Retrieve ImGui IO object
    ImGui::StyleColorsDark(); // Set the dark theme for ImGui
    // Load a custom font from the system
    NSString *FontPath = @"/System/Library/Fonts/AppFonts/AppleGothic.otf";
    // Uncomment the line below if you want to use a Chinese font
    // _espFont = io.Fonts->AddFontFromFileTTF(FontPath.UTF8String, 40.f,NULL,io.Fonts->GetGlyphRangesChineseSimplifiedCommon());
    // Setup FontAwesome icon font configuration
    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 }; // Define the range for FontAwesome icons
    ImFontConfig icons_config;
    ImFontConfig CustomFont;
    CustomFont.FontDataOwnedByAtlas = false; // Set custom font not to be owned by the atlas
    // Configure FontAwesome settings
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    // Add custom fonts to ImGui from memory
    io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 21.f, &CustomFont);
    _espFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);
    // Add default font to ImGui
    io.Fonts->AddFontDefault();
    ImGui_ImplMetal_Init(_device); // Initialize ImGui for Metal rendering

    return self; // Return self for initialization completion
}

-(MTKView *)mtkView
{
    return (MTKView *)self.view; // Cast the current view to an MTKView
}
// Method to open the menu when a gesture is recognized
- (void)openMenu:(UITapGestureRecognizer *)tap {
    if(tap.state == UIGestureRecognizerStateEnded) {
        MenDeal = true; // Set the menu state to active when the gesture ends
    }
}
// Override loadView to initialize and configure the view
-(void)loadView
{
    // Get the screen width and height
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    // Initialize the MTKView with the screen's dimensions
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    // Initialize a custom overlay to prevent screenshots
    noScreenShotView = [[HeeeNoScreenShotView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    noScreenShotView.backgroundColor = [UIColor clearColor]; // Transparent background
    noScreenShotView.userInteractionEnabled = NO; // Disable interaction with the overlay
    [[UIApplication sharedApplication].keyWindow addSubview:noScreenShotView]; // Add overlay to the main window
}
// Override viewDidLoad to configure the Metal view and UI elements
-(void)viewDidLoad
{
    [super viewDidLoad];
    self.mtkView.device = self.device; // Set the device for the MTKView
    self.mtkView.delegate = self; // Set the delegate for Metal rendering callbacks
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0); // Set clear color to transparent
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0]; // Set background to transparent
    self.mtkView.clipsToBounds = YES; // Ensure content is clipped to the view bounds
    // Initialize and display a new UIWindow
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = self;
    self.window.hidden = NO;
    self.view.hidden = NO;
    [noScreenShotView addSubview:self.window]; // Add the window to the overlay
    // Configure a gesture recognizer to open the menu with triple tap
    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
    UITapGestureRecognizer *tapGestureRecognizerMenuH = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(openMenu:)];
    tapGestureRecognizerMenuH.numberOfTapsRequired = 3; // Triple tap to activate
    tapGestureRecognizerMenuH.numberOfTouchesRequired = 3; // Triple finger tap to activate
    [mainWindow addGestureRecognizer: tapGestureRecognizerMenuH]; // Add gesture recognizer to the main window
}
// Implement MTKViewDelegate method for rendering
#pragma mark - MTKViewDelegate
-(void)drawInMTKView:(MTKView*)view{
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width; // Set ImGui display width
    io.DisplaySize.y = view.bounds.size.height; // Set ImGui display height
    // Get screen scale for retina or non-retina devices
    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale); // Set ImGui framebuffer scale
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60); // Set frame delta time
    // Create a Metal command buffer
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor == nil) {
    [commandBuffer commit]; // If no render pass descriptor, commit the command buffer
    return;
    }
    // Enable or disable user interaction based on menu state
    if (MenDeal == true) {
    [self.view setUserInteractionEnabled:YES];
    [self.window setUserInteractionEnabled:YES];
    } else {
    [self.view setUserInteractionEnabled:NO];
    [self.window setUserInteractionEnabled:NO];
    }
    // Start a new frame for ImGui using Metal's render pass descriptor
    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
    ImGui::NewFrame();
    // Get the current font and adjust the scale
    ImFont* font = ImGui::GetFont();
    font->Scale = 16.f / font->FontSize; // Scale the font for proper sizing
    // Calculate the center position for the menu window
    CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 380) / 2;
    CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 260) / 2;
    ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver); // Set window position on first appearance
    // Check if the menu should be open (MenDeal is true)
    if (MenDeal == true) {
        // Begin the main cheat menu window with dynamic title
        ImGui::Begin(make_string("GLESquad ~ Call of Duty© Mobile Global | 1.0.47").c_str(), &MenDeal, ImGuiWindowFlags_AlwaysAutoResize);
        ImGui::PushItemWidth(ImGui::GetWindowWidth() * 0.55f); // Set width for input fields
        // Create tab bar for different cheat categories
        if (ImGui::BeginTabBar(make_string("##tabbarmain").c_str())) {
            // Aimbot Tab
            if (ImGui::BeginTabItem(make_string(ICON_FA_CROSSHAIRS " Aimbot").c_str())) {
                ImGui::Spacing();
                ImGui::Checkbox(make_string("Enable Aimbot").c_str(), &CheatState::enable_aimbot); // Toggle aimbot
                ImGui::Combo(make_string("Aim Target").c_str(), &CheatState::aim_target, "Closest\0Inside FOV\0"); // Target selection
                ImGui::Combo(make_string("Aim Location").c_str(), &CheatState::aim_location, "Head\0Chest\0Legs\0"); // Location of aim
                ImGui::Combo(make_string("Aim Trigger").c_str(), &CheatState::aim_trigger, "Always\0Firing\0Aiming\0"); // Trigger condition
                ImGui::EndTabItem();
            }
            // Esp Tab
            if (ImGui::BeginTabItem(make_string(ICON_FA_EYE " Esp").c_str())) {
                ImGui::Spacing();
                ImGui::Checkbox(make_string("Enable Esp").c_str(), &CheatState::show_esp); // Toggle ESP
                ImGui::Separator();
                ImGui::Checkbox(make_string("Esp - Lines").c_str(), &CheatState::show_esplines); // Show ESP lines
                ImGui::Checkbox(make_string("Esp - Boxes").c_str(), &CheatState::show_espboxes); // Show ESP boxes
                ImGui::Checkbox(make_string("Esp - Info").c_str(), &CheatState::show_espinfo); // Show ESP info
                ImGui::Separator();
                ImGui::SliderInt(make_string("Esp - Distance").c_str(), &CheatState::distanceValue, 0, 200); // ESP distance slider
                ImGui::Spacing();
                ImGui::EndTabItem();
            }
            // Settings Tab
            if (ImGui::BeginTabItem(make_string(ICON_FA_COGS " Settings").c_str())) {
                ImGui::Checkbox(make_string("Stream Mode").c_str(), &CheatState::stream_mode); // Toggle stream mode
                ImGui::Spacing();
                ImGui::Checkbox(make_string("Hide Top Label").c_str(), &CheatState::hide_top_label); // Toggle top label visibility
                ImGui::Spacing();
                ImGui::Checkbox(make_string("Circle FOV").c_str(), &CheatState::enable_circleFov); // Enable/Disable FOV circle
                ImGui::Spacing();
                ImGui::SliderInt(make_string("Circle Size").c_str(), &CheatState::circleSizeValue, 0, 255); // FOV circle size slider
                ImGui::Spacing();
                ImGui::ColorEdit3(make_string("Color Esp").c_str(), &*(float*)CheatState::colorEsp, ImGuiColorEditFlags_NoInputs); // Change ESP color
                ImGui::Spacing();
                // Change menu style (Dark, Light, Classic)
                if (ImGui::Combo(make_string("Color Menu").c_str(), &CheatState::style_idx, "Dark\0Light\0Classic\0")) {
                    switch (CheatState::style_idx) {
                        case 0: ImGui::StyleColorsDark(); break; // Dark theme
                        case 1: ImGui::StyleColorsLight(); break; // Light theme
                        case 2: ImGui::StyleColorsClassic(); break; // Classic theme
                    }
                }
                ImGui::Spacing();
                ImGui::EndTabItem();
            }
            // Bullet Tracking Tab
            if (ImGui::BeginTabItem(make_string(" Bullet Tracking").c_str())) { // Bullet tracking icon or label
                ImGui::Spacing();
                ImGui::Checkbox(make_string("Enable Bullet Tracking").c_str(), &CheatState::enable_bullet_tracking); // Toggle bullet tracking
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar(); // End of tab bar
        }
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        // Display performance statistics
        ImGui::Text("This is a working build for GLESquad CODM Cheat Menu\n%.3f ms/frame (%.1f FPS)", 60.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
        ImGui::End(); // End of main window
    }
    // Ensure that the NSObject load method is called only once
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [NSObject load];
    });
    // Toggle secure mode to prevent or allow screenshots
    if (CheatState::stream_mode) {
        [noScreenShotView setSecure: YES]; // Enable secure mode (prevent screenshots)
    } else {
        [noScreenShotView setSecure: NO]; // Disable secure mode (allow screenshots)
    }
    // Toggle visibility of the top label based on cheat state
    if (CheatState::hide_top_label) {
        menuTitle.hidden = YES; // Hide the top label
    } else {
        menuTitle.hidden = NO; // Show the top label
    }
    // Reset enemy and aim variables
    totalEnemies = 0;
    tDistance = 0;
    needAdjustAim = false;
    markDistance = kWidth;
    markScreenPos = Vector2(kWidth/2, kHeight/2);
    markDis = kWidth;
    tDis = 0;
    // ESP rendering logic
    if (CheatState::show_esp) {
        if (*getGameInstance) {
            auto gameInstance = getGameInstance(); // Get game instance
            if (gameInstance != nullptr) {
                Matrix4x4 viewMatrix = GetWorldToCamera(); // Get the view matrix for ESP rendering
                // Retrieve the projection matrix for 3D rendering
                Matrix4x4 projectionMatrix = GetProjectionMatrixInternal();
                // Get the list of enemies from the game instance
                monoList<void **> *enemyList = *(monoList<void **>**)((uint64_t)gameInstance + 0x158); // BaseGame$$EnemyPawns
                if (enemyList != nullptr) {
                    int enemyCount = enemyList->getSize(); // Get the number of enemies
                    for (int i = 0; i < enemyCount; i++) {
                        // Get enemy information from the enemy list
                        void* enemyInfo = *(void **)((uint64_t)enemyList->getItems()[i] + 0x590); // Pawn$$m_PlayerInfo
                        if (enemyInfo != nullptr) {
                            // Get the world position of the enemy
                            Vector3 enemyPositionWorld = GetPlayerPosition(enemyList->getItems()[i]);
                            // Convert to view coordinates
                            Vector4 enemyPositionView = GetViewCoords(enemyPositionWorld, viewMatrix);
                            // Convert to clip coordinates
                            Vector4 enemyPositionClip = GetClipCoords(enemyPositionView, projectionMatrix);
                            // Normalize the coordinates
                            Vector3 enemyPositionNormalized = NormalizeCoords(enemyPositionClip);
                            // Convert to screen coordinates
                            Vector2 enemyPositionScreen = GetScreenCoords(enemyPositionNormalized);
                            // Get the head bone position of the enemy
                            void* headBone = *(void **)((uint64_t)enemyList->getItems()[i] + 0x2E8); // Pawm$$m_HeadBone
                            if (headBone != nullptr) {
                                // Get the world position of the enemy's head
                                Vector3 enemyHeadPositionWorld = GetTransformPositionInternal(headBone);
                                // Convert to view coordinates
                                Vector4 enemyHeadPositionView = GetViewCoords(enemyHeadPositionWorld, viewMatrix);
                                // Convert to clip coordinates
                                Vector4 enemyHeadPositionClip = GetClipCoords(enemyHeadPositionView, projectionMatrix);
                                enemyHeadPositionClip.Y += 0.5f; // Adjust Y coordinate
                                // Normalize head position coordinates
                                Vector3 enemyHeadPositionNormalized = NormalizeCoords(enemyHeadPositionClip);
                                // Convert to screen coordinates
                                Vector2 enemyHeadPositionScreen = GetScreenCoords(enemyHeadPositionNormalized);
                                // Check if the enemy is within the field of view
                                if (GetInsideFov(kWidth, kHeight, enemyHeadPositionScreen, CheatState::circleSizeValue)) {
                                    tDistance = GetCenterOffsetForVector(enemyHeadPositionScreen, Vector2(kWidth, kHeight));
                                    if (tDistance <= CheatState::circleSizeValue && tDistance < markDistance) {
                                        needAdjustAim = true; // Mark that adjustment is needed
                                        if (needAdjustAim) {
                                            markDistance = tDistance; // Update the mark distance
                                            //MSHookFunction((void*)(getRealOffset(0x10A6F7998)), (void*)CalWeaponFire, (void**)&orig_CalWeaponFire); //потом нужно нормально сделать
                                            TargetPos = enemyHeadPositionWorld; // Set target position for aiming
                                        }
                                    }
                                }
                                // Check if the enemy is facing the player and visible on screen
                                bool isFacing = (enemyPositionClip.Z >= 0.01f); // Check if facing the player
                                bool isVisible = (enemyPositionScreen.X >= 0 && enemyPositionScreen.X <= kWidth); // Check visibility
                                if (isVisible && isFacing) {
                                    // Retrieve the local player's position
                                    Vector3 localPlayerPosition = Vector3(0, 0, 0);
                                    if (*getLocalPawn != nullptr && getLocalPawn() != nullptr) {
                                        localPlayerPosition = GetPlayerPosition(getLocalPawn()); // Get local player's position
                                    }
                                    // Calculate distance between local player and enemy
                                    float distance = Vector3::Distance(localPlayerPosition, enemyPositionWorld);
                                    bool shouldShow = CheatState::distanceValue >= distance; // Check if enemy is within display range
                                    NSString *enemyName = GetEnemyName(distance, enemyInfo); // Get enemy's name
                                    bool isAlive = false; // Flag for enemy's alive status
                                    if (*IsAlive != nullptr) {
                                        isAlive = IsAlive(enemyList->getItems()[i]); // Check if enemy is alive
                                    }
                                    if (!isAlive) continue; // Skip if the enemy is not alive
                                    // Draw ESP lines if enabled
                                    if (CheatState::show_esplines && isAlive) {
                                        if (CheatState::show_espinfo) {
                                            RenderLine(ImVec2(kWidth / 2, 0), ImVec2(enemyHeadPositionScreen.X, enemyHeadPositionScreen.Y - 20),
                                                    ImColor(CheatState::colorEsp[0], CheatState::colorEsp[1], CheatState::colorEsp[2]), 0.9); // Draw line with offset
                                        } else {
                                            RenderLine(ImVec2(kWidth / 2, 0), ImVec2(enemyHeadPositionScreen.X, enemyHeadPositionScreen.Y),
                                                    ImColor(CheatState::colorEsp[0], CheatState::colorEsp[1], CheatState::colorEsp[2]), 0.9); // Draw line directly to head
                                        }
                                    }
                                    // Draw enemy name if conditions are met
                                    if (CheatState::show_espinfo && shouldShow && isAlive) {
                                        ImVec2 nameWidth = _espFont->CalcTextSizeA(12.0f, MAXFLOAT, 0.0f, [enemyName UTF8String]); // Calculate text width
                                        DrawText2(_espFont, 12,
                                                ImVec2(enemyHeadPositionScreen.X - (nameWidth.x / 2.0f), enemyHeadPositionScreen.Y - 16),
                                                ImColor(255, 255, 51), [enemyName UTF8String], ImColor(0, 0, 0, 190)); // Draw enemy name with shadow
                                        float health = 0.0f;
                                        float maxHealth = 0.0f;
                                        if (*GetHealth != nullptr) {
                                            health = GetHealth(enemyList->getItems()[i]); // Get enemy's current health
                                        }
                                        void* attackableInfo = *(void **)((uint64_t)enemyList->getItems()[i] + 0x78); // AttackableTarget$$m_AttackableInfo
                                        maxHealth = *(float *)((uint64_t)attackableInfo + 0x38); // AttackableTargetInfo$$m_MaxHealth
                                        DrawHealthBar(health, maxHealth, enemyHeadPositionScreen.X, enemyHeadPositionScreen.Y); // Draw health bar
                                    }
                                    // Draw bounding box if enabled
                                    if (CheatState::show_espboxes && shouldShow && isAlive) {
                                        float height = abs(enemyPositionScreen.Y - enemyHeadPositionScreen.Y); // Calculate box height
                                        float width = height * 0.65f; // Calculate box width
                                        DrawBox(enemyHeadPositionScreen.X - (width * 0.5f), enemyHeadPositionScreen.Y,
                                                width, height, ImColor(CheatState::colorEsp[0], CheatState::colorEsp[1], CheatState::colorEsp[2]), 0.9, 0.9); // Draw box around enemy
                                     }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    // Enable aimbot if the feature is active
    if (CheatState::enable_aimbot) {
    Aimbot(); // Activate aimbot functionality
    }
    // Get the background draw list for rendering
    auto draw = ImGui::GetBackgroundDrawList();
    // If the circle field of view (FOV) is enabled, draw a red circle at the center of the screen
    if (CheatState::enable_circleFov) {
    draw->AddCircle(ImVec2(kWidth / 2, kHeight / 2), CheatState::circleSizeValue, IM_COL32(255, 0, 0, 255), 100, 1.0f); // Draw FOV circle
    }
    // Render ImGui elements
    ImGui::Render();
    ImDrawData* drawData = ImGui::GetDrawData();
    id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
    [renderEncoder pushDebugGroup:@"Dear ImGui rendering Jairback"]; // Debug group for rendering
    ImGui_ImplMetal_RenderDrawData(drawData, commandBuffer, renderEncoder); // Render the draw data
    [renderEncoder popDebugGroup]; // End debug group
    [renderEncoder endEncoding]; // End encoding commands
    [commandBuffer presentDrawable:view.currentDrawable]; // Present the drawable to the screen
    [commandBuffer commit]; // Commit the command buffer
}
// Method called when the drawable size changes
-(void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size_
{
// This can be used to handle changes in drawable size
}
// Interaction Handling
-(void)updateIOWithTouchEvent:(UIEvent *)event{
    UITouch *anyTouch = event.allTouches.anyObject; // Get any touch from the event
    CGPoint touchLocation = [anyTouch locationInView:self.view]; // Get touch location in the view
    ImGuiIO &io = ImGui::GetIO();
    io.AddMousePosEvent(touchLocation.x, touchLocation.y); // Update mouse position in ImGui
    BOOL hasActiveTouch = NO; // Flag to check if there's an active touch
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES; // Set flag if there is an active touch
            break;
        }
    }
    io.AddMouseButtonEvent(0, hasActiveTouch); // Update mouse button state in ImGui
}
// Touch event handlers
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event      { [self updateIOWithTouchEvent:event]; }
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event      { [self updateIOWithTouchEvent:event]; }
-(void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event  { [self updateIOWithTouchEvent:event]; }
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event      { [self updateIOWithTouchEvent:event]; }
// Check if a point is within the field of view (FOV)
static bool GetInsideFov(float ScreenWidth, float ScreenHeight, Vector2 PlayerBone, float FovRadius) {
// Calculate the center point relative to the screen center
    Vector2 centerPoint;
    centerPoint.X = PlayerBone.X - (ScreenWidth / 2); // Offset from screen center in X
    centerPoint.Y = PlayerBone.Y - (ScreenHeight / 2); // Offset from screen center in Y
    // Check if the squared distance from the center point to the origin is within the FOV radius
    // This avoids the need for a square root calculation, improving performance
    if (centerPoint.X * centerPoint.X + centerPoint.Y * centerPoint.Y <= FovRadius * FovRadius) return true; // Point is within the FOV
    return false; // Point is outside the FOV
}
// Calculate the distance from the center of the canvas to a given point
static int GetCenterOffsetForVector(Vector2 point, Vector2 CanvasSize) {
    return sqrt(pow(point.X - CanvasSize.X / 2, 2.0) + pow(point.Y - CanvasSize.Y / 2, 2.0)); // Euclidean distance
}
// Aimbot function to aim at enemies
void Aimbot() {
    if (!CheatState::enable_aimbot) return; // Exit if aimbot is not enabled
    void* localPawn = getLocalPawn();
    if (!localPawn) return; // Exit if local player is not found
    // Check if the aim trigger is set to "Firing" or "Aiming"
    if (CheatState::aim_trigger == 1) { // Firing
        if (!GetIsFiring(localPawn)) return; // Exit if the player is not firing
    } else if (CheatState::aim_trigger == 2) { // Aiming
        if (!GetIsAiming(localPawn)) return; // Exit if the player is not aiming
    }
    Matrix4x4 viewMatrix = GetWorldToCamera(); // Get the view matrix for 3D rendering
    Matrix4x4 projectionMatrix = GetProjectionMatrixInternal(); // Get the projection matrix
    void* gameInstance = getGameInstance();
    if (!gameInstance) return; // Exit if game instance is not found
    monoList<void **> *enemyList = *(monoList<void **>**)((uint64_t)gameInstance + 0x158); // BaseGame$$EnemyPawns
    if (!enemyList) return; // Exit if enemy list is not found
    int enemyCount = enemyList->getSize(); // Get the number of enemies
    for (int i = 0; i < enemyCount; i++) {
        void* enemyPawn = enemyList->getItems()[i]; // Get the current enemy
        if (!enemyPawn) continue; // Skip if enemy reference is invalid
        bool isAlive = false; // Flag for enemy's alive status
        if (*IsAlive != nullptr) {
            isAlive = IsAlive(enemyPawn); // Check if the enemy is alive
        }
        if (!isAlive) continue; // Skip if the enemy is not alive
        Vector3 enemyPositionWorld = GetPlayerPosition(enemyPawn); // Get the world position of the enemy
        Vector3 localPosition = GetPlayerPosition(localPawn); // Get the local player's position
        float distance = Vector3::Distance(localPosition, enemyPositionWorld); // Calculate distance to the enemy
        // Determine targeting logic based on CheatState settings
        if (CheatState::aim_target == 0) {
            // Logic for targeting the closest enemy
        } else if (CheatState::aim_target == 1) {
            // Logic for targeting enemies within the field of view
        }
        // Get the head bone information from the enemy
        void* headBone = *(void **)((uint64_t)enemyPawn + 0x2F0); // Get head bone information
        if (!headBone) continue; // Skip if head bone is not found
        // Retrieve the target position based on the head bone
        Vector3 targetPosition = GetTransformPositionInternal(headBone); // Get the target position
        // Adjust the target position based on the aiming location setting
        if (CheatState::aim_location == 1) {
            targetPosition.y -= 0.2f; // Aim for the chest
        } else if (CheatState::aim_location == 2) {
            targetPosition.y -= 0.4f; // Aim for the waist
        }
        // Convert the target position to view coordinates
        Vector4 targetPositionView = GetViewCoords(targetPosition, viewMatrix); // Convert to view coordinates
        // Convert view coordinates to clip coordinates
        Vector4 targetPositionClip = GetClipCoords(targetPositionView, projectionMatrix); // Convert to clip coordinates
        // Normalize the clip coordinates
        Vector3 targetPositionNormalized = NormalizeCoords(targetPositionClip); // Normalize coordinates
        // Convert normalized coordinates to screen coordinates
        Vector2 targetPositionScreen = GetScreenCoords(targetPositionNormalized); // Convert to screen coordinates
        // Get the main camera
        void* mainCamera = GetMainCamera(); // Get the main camera
        if (!mainCamera) continue; // Skip if the camera is not found
        // Get the camera's transform component
        void* mainView = GetComponentTransform(mainCamera); // Get the camera's transform component
        if (!mainView) continue; // Skip if the transform component is not found
        // Get the position of the main camera
        Vector3 mainViewPos = GetTransformPositionInternal(mainView); // Get the camera position
        // Check if the target position is within the field of view (FOV)
        if (GetInsideFov(kWidth, kHeight, targetPositionScreen, CheatState::circleSizeValue)) {
            // Calculate the distance from the center of the screen to the target position
            tDistance = GetCenterOffsetForVector(targetPositionScreen, Vector2(kWidth, kHeight));
            // Check if the distance is within the circle size value and less than the mark distance
            if (tDistance <= CheatState::circleSizeValue && tDistance < markDistance) {
                needAdjustAim = true; // Set the need for aim adjustment
                if (needAdjustAim) {
                    markDistance = tDistance; // Update the mark distance
                    // Aim at the enemy
                    setAimRotation(localPawn, Quaternion::LookRotation(targetPosition - mainViewPos)); // Set the aim direction towards the target
                }
            }
        }
    }
}
// Function pointer declarations for original functions
typedef void (*WeaponFireComponent_Instant_CreateBulletLine_t)(void* instance, void* bulletLine);
typedef void (*CreateBulletProjectile_t)(void* instance, void* bulletProjectile);
// Declare original function pointers
WeaponFireComponent_Instant_CreateBulletLine_t oWeaponFireComponent_Instant_CreateBulletLine = nullptr;
CreateBulletProjectile_t oCreateBulletProjectile = nullptr;
// Hooked function to create a bullet line
void WeaponFireComponent_Instant_CreateBulletLine(void* instance, void* bulletLine) {
    // Call the original function if available
    if (oWeaponFireComponent_Instant_CreateBulletLine) {
        oWeaponFireComponent_Instant_CreateBulletLine(instance, bulletLine);
    }
    // Bullet tracking logic
    if (CheatState::enable_bullet_tracking) {
        Vector3 bulletPosition = *(Vector3*)((uint64_t)bulletLine + 0x18); // Get bullet position
        // Calculate the direction
        if (*getLocalPawn != nullptr && getLocalPawn() != nullptr) {
            Vector3 localPosition = GetPlayerPosition(getLocalPawn()); // Get local player position
            Vector3 direction = bulletPosition - localPosition; // Calculate direction
            Vector3 aimDirection = Vector3::Normalized(direction); // Normalize the direction
            // Apply aim direction
            AdjustPlayerAim(aimDirection); // Adjust the player's aim
        }
    }
}
// Hooked function to create a bullet projectile
void CreateBulletProjectile(void* instance, void* bulletProjectile) {
// Call the original function if available
    if (oCreateBulletProjectile) {
        oCreateBulletProjectile(instance, bulletProjectile);
    }
    // Bullet tracking logic
    if (CheatState::enable_bullet_tracking) {
        Vector3 bulletPosition = *(Vector3*)((uint64_t)bulletProjectile + 0x18); // пока не совсем понял что это
        // Calculate the direction
        if (*getLocalPawn != nullptr && getLocalPawn() != nullptr) {
            Vector3 localPosition = GetPlayerPosition(getLocalPawn()); // Get local player position
            Vector3 direction = bulletPosition - localPosition; // Calculate direction
            Vector3 aimDirection = Vector3::Normalized(direction); // Normalize the direction
            // Apply aim direction
            AdjustPlayerAim(aimDirection); // Adjust the player's aim
        }
    }
}
// Function to adjust the player's aim direction
void AdjustPlayerAim(Vector3 aimDirection) {
    void* localPawn = getLocalPawn();
    if (!localPawn) return; // Exit if local player is not found
    void* mainCamera = GetMainCamera(); // Get the main camera
    if (!mainCamera) return; // Exit if main camera is not found
    void* mainView = GetComponentTransform(mainCamera); // Get the camera's transform component
    if (!mainView) return; // Exit if transform component is not found
    Vector3 mainViewPos = GetTransformPositionInternal(mainView); // Get the camera position
    setAimRotation(localPawn, Quaternion::LookRotation(aimDirection)); // Adjust the aim direction
}
@end
