#ifndef CheatState_h
#define CheatState_h

namespace CheatState {
    extern bool enable_circleFov;
    extern float circleSizeValue;
}

#endif /* CheatState_h */ 