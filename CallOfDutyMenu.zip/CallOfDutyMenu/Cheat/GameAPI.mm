//
//  GameAPI.cpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 18/05/2025.
//

#include "GameAPI.hpp"
#include "imgui.h"

float GameAPI::FOVCircleSize = 100.0f;
ImVec4 GameAPI::FOVCircleColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); 

// Camera Function
void* (*GameAPI::getMainCamera)() = (void* (*) ())getRealOffset(0x107323900);
Matrix4x4 (*GameAPI::getProjectionMatrix)(void* camera) = (Matrix4x4 (*) (void*))getRealOffset(0x1073232AC);
Matrix4x4 (*GameAPI::getWorldToCameraMatrix)(void* camera) = (Matrix4x4 (*) (void*))getRealOffset(0x1073231C4);

// Component Function

void* (*GameAPI::getComponentTransform)(void* component) = (void* (*) (void*))getRealOffset(0x1073292D0);

// Transform Function

void (*GameAPI::getTransformPosition)(void* transform, Vector3* out) = (void (*) (void*, Vector3*))getRealOffset(0x10739E44C);

void (*GameAPI::getTransformLocalPosition)(void* transform, Vector3* out) = (void (*) (void*, Vector3*))getRealOffset(0x10739E4AC);

// Pawn Function

bool (*GameAPI::isAlive)(void* info) = (bool (*) (void*))getRealOffset(0x10159C30C);

float (*GameAPI::getHealth)(void* Pawn) = (float (*) (void*))getRealOffset(0x10178DC74);

void (*GameAPI::setAimPosition)(void*, Quaternion) = (void (*) (void*, Quaternion))getRealOffset(0x1015AC4F0);

bool (*GameAPI::isAiming)(void* info) = (bool (*) (void*))getRealOffset(0x1015A5560);

// GamePlay Function

void* (*GameAPI::getLocalPawn)() = (void* (*) ())getRealOffset(0x101E3A044);

void* (*GameAPI::getGameInstance)() = (void* (*) ())getRealOffset(0x101E66C44);

// PlayerInfo Function

bool (*GameAPI::isRobot)(void* info) = (bool (*) (void*))getRealOffset(0x1020B51AC);

// Drive Handle

bool (*GameAPI::isFiring)(void* info) = (bool (*) (void*))getRealOffset(0x101E9E214);

//////////////////////////////////////////////////////////////////
///                                                            ///
///                        OTHER DECLARATION NEEDED            ///
///                                                            ///
//////////////////////////////////////////////////////////////////


Vector3 GameAPI::getPlayerPosition(void *Player) {
    Vector3 location;
    GameAPI::getTransformPosition(GameAPI::getComponentTransform(Player), &location);
    return location;
}

Vector3 GameAPI::getTransformPositionInternal(void *Transform) {
    Vector3 location;
    GameAPI::getTransformPosition(Transform, &location);
    return location;
}

Vector3 GameAPI::getPlayerLocalPosition(void *Player) {
    Vector3 location;
    GameAPI::getTransformPosition(GameAPI::getComponentTransform(Player), &location);
    return location;
}

Matrix4x4 GameAPI::getProjectionMatrixInternal() {
    if (GameAPI::getMainCamera() != nullptr){
        return GameAPI::getProjectionMatrix(GameAPI::getMainCamera());
    }
    return Matrix4x4();
}

Matrix4x4 GameAPI::getWorldToCamera() {
    if (GameAPI::getMainCamera() != nullptr) {
        return GameAPI::getWorldToCameraMatrix(GameAPI::getMainCamera());
    }
    return Matrix4x4();
}

Vector4 GameAPI::GetViewCoords(Vector3 pos, Matrix4x4 modelViewMatrix) {
    Vector4 viewPos = Vector4(0, 0, 0, 0);
    viewPos.X = pos.x * modelViewMatrix[0][0] + pos.y * modelViewMatrix[1][0] + pos.z * modelViewMatrix[2][0] + modelViewMatrix[3][0];
    viewPos.Y = pos.x * modelViewMatrix[0][1] + pos.y * modelViewMatrix[1][1] + pos.z * modelViewMatrix[2][1] + modelViewMatrix[3][1];
    viewPos.Z = pos.x * modelViewMatrix[0][2] + pos.y * modelViewMatrix[1][2] + pos.z * modelViewMatrix[2][2] + modelViewMatrix[3][2];
    viewPos.W = pos.x * modelViewMatrix[0][3] + pos.y * modelViewMatrix[1][3] + pos.z * modelViewMatrix[2][3] + modelViewMatrix[3][3];
    return viewPos;
}

Vector4 GameAPI::GetClipCoords(Vector4 pos, Matrix4x4 projectionMatrix) {
    Vector4 clipPos = Vector4(0, 0, 0, 0);
    clipPos.X = pos.X * projectionMatrix[0][0] + pos.Y * projectionMatrix[1][0] + pos.Z * projectionMatrix[2][0] + pos.W * projectionMatrix[3][0];
    clipPos.Y = pos.X * projectionMatrix[0][1] + pos.Y * projectionMatrix[1][1] + pos.Z * projectionMatrix[2][1] + pos.W * projectionMatrix[3][1];
    clipPos.Z = pos.X * projectionMatrix[0][2] + pos.Y * projectionMatrix[1][2] + pos.Z * projectionMatrix[2][2] + pos.W * projectionMatrix[3][2];
    clipPos.W = pos.X * projectionMatrix[0][3] + pos.Y * projectionMatrix[1][3] + pos.Z * projectionMatrix[2][3] + pos.W * projectionMatrix[3][3];
    return clipPos;
}

Vector3 GameAPI::NormalizeCoords(Vector4 pos) {
    Vector3 normalized = Vector3(0, 0, 0);
    normalized.x = pos.X / pos.W;
    normalized.y = pos.Y / pos.W;
    normalized.z = pos.Z / pos.W;
    return normalized;
}

Vector2 GameAPI::GetScreenCoords(Vector3 pos) {
    Vector2 screen = Vector2(0, 0);
    screen.X = (kWidth / 2.0 * pos.x) + (pos.x + kWidth / 2.0);  // Calculate X screen coordinate
    screen.Y = -(kHeight / 2.0 * pos.y) + (pos.y + kHeight / 2.0);  // Calculate Y screen coordinate
    return screen;
}

//NSString *GameAPI::GetEnemyName(float distance, void *enemyInfo) {
//    if (!enemyInfo) {
//        NSLog(@"GetEnemyName - enemyInfo est null");
//        return @"Unknown";
//    }
//    
//    NSString *dis = [NSString stringWithFormat:@"%d", (int)distance];
//    
//    // Vérification de l'adresse de m_NickName
//    uint64_t nickNameOffset = 0x150;
//    void* nickNamePtr = (void*)((uint64_t)enemyInfo + nickNameOffset);
//    NSLog(@"GetEnemyName - Adresse de m_NickName: %p", nickNamePtr);
//    
//    if (!nickNamePtr) {
//        NSLog(@"GetEnemyName - nickNamePtr est null");
//        return [NSString stringWithFormat:@"[%@M] Unknown", dis];
//    }
//    
//    // Vérification du pointeur _monoString
//    _monoString *m_NickName = *(_monoString **)nickNamePtr;
//    NSLog(@"GetEnemyName - m_NickName: %p", m_NickName);
//    
//    if (!m_NickName) {
//        NSLog(@"GetEnemyName - m_NickName est null");
//        return [NSString stringWithFormat:@"[%@M] Unknown", dis];
//    }
//    
//    // Vérification de la méthode toNSString
//    if (!m_NickName->toNSString) {
//        NSLog(@"GetEnemyName - toNSString est null");
//        return [NSString stringWithFormat:@"[%@M] Unknown", dis];
//    }
//    
//    NSString *nameEnemy = nil;
//    @try {
//        nameEnemy = m_NickName->toNSString();
//        if (!nameEnemy) {
//            NSLog(@"GetEnemyName - toNSString a retourné null");
//            nameEnemy = @"Unknown";
//        }
//    } @catch (NSException *exception) {
//        NSLog(@"GetEnemyName - Exception lors de toNSString: %@", exception);
//        nameEnemy = @"Error";
//    }
//    
//    bool IsRobot = GameAPI::isRobot(enemyInfo);
//    if (IsRobot || nameEnemy.length == 0) {
//        nameEnemy = @"[AI]";
//    }
//    
//    NSString *nameAndDistance = [NSString stringWithFormat:@"[%@M] %@", dis, nameEnemy];
//    return nameAndDistance;
//}

bool GameAPI::GetInsideFov(float ScreenWidth, float ScreenHeight, Vector2 PlayerBone, float FovRadius) {
// Calculate the center point relative to the screen center
    Vector2 centerPoint;
    centerPoint.X = PlayerBone.X - (ScreenWidth / 2); // Offset from screen center in X
    centerPoint.Y = PlayerBone.Y - (ScreenHeight / 2); // Offset from screen center in Y
    // Check if the squared distance from the center point to the origin is within the FOV radius
    // This avoids the need for a square root calculation, improving performance
    if (centerPoint.X * centerPoint.X + centerPoint.Y * centerPoint.Y <= FovRadius * FovRadius) return true; // Point is within the FOV
    return false; // Point is outside the FOV
}

int GameAPI::GetCenterOffsetForVector(Vector2 point, Vector2 CanvasSize) {
    return sqrt(pow(point.X - CanvasSize.X / 2, 2.0) + pow(point.Y - CanvasSize.Y / 2, 2.0));
}

// FOV Circle implementation
void GameAPI::DrawFOVCircle(float screenWidth, float screenHeight, float radius, ImU32 color) {
    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    ImVec2 center(screenWidth / 2, screenHeight / 2);
    
    // Utiliser la couleur personnalisée si aucune n'est spécifiée
    if (color == IM_COL32(255, 0, 0, 255)) {
        color = ImGui::ColorConvertFloat4ToU32(FOVCircleColor);
    }
    
    drawList->AddCircle(center, radius, color, 0, 2.0f);
}

bool GameAPI::IsPointInFOVCircle(float screenWidth, float screenHeight, Vector2 point, float radius) {
    // Utiliser FOVCircleSize si radius n'est pas spécifié
    float finalRadius = (radius <= 0.0f) ? FOVCircleSize : radius;
    
    // Calculate the center point
    Vector2 center(screenWidth / 2, screenHeight / 2);
    
    // Calculate the distance from the point to the center
    float distance = sqrt(
        pow(point.X - center.X, 2) + 
        pow(point.Y - center.Y, 2)
    );
    
    // Check if the point is within the circle
    return distance <= finalRadius;
}

void GameAPI::SetFOVCircleSize(float size) {
    if (size >= 0.0f) {
        FOVCircleSize = size;
    }
}

float GameAPI::GetFOVCircleSize() {
    return FOVCircleSize;
}

void GameAPI::SetFOVCircleColor(const ImVec4& color) {
    FOVCircleColor = color;
}

ImVec4 GameAPI::GetFOVCircleColor() {
    return FOVCircleColor;
}

void GameAPI::Initialize() {
    NSLog(@"GameAPI::Initialize - Début");
    
    // Log des adresses des fonctions
    NSLog(@"GameAPI::Initialize - getGameInstance: %p", getGameInstance);
    NSLog(@"GameAPI::Initialize - getLocalPawn: %p", getLocalPawn);
    NSLog(@"GameAPI::Initialize - isAlive: %p", isAlive);
    NSLog(@"GameAPI::Initialize - getHealth: %p", getHealth);
    NSLog(@"GameAPI::Initialize - getPlayerPosition: %p", getPlayerPosition);
    NSLog(@"GameAPI::Initialize - getTransformPositionInternal: %p", getTransformPositionInternal);
    NSLog(@"GameAPI::Initialize - getWorldToCamera: %p", getWorldToCamera);
    NSLog(@"GameAPI::Initialize - getProjectionMatrixInternal: %p", getProjectionMatrixInternal);
    NSLog(@"GameAPI::Initialize - getComponentTransform: %p", getComponentTransform);
    NSLog(@"GameAPI::Initialize - getAimPosition: %p", setAimPosition);
    NSLog(@"GameAPI::Initialize - isAiming: %p", isAiming);
    NSLog(@"GameAPI::Initialize - isFiring: %p", isFiring);
    NSLog(@"GameAPI::Initialize - isRobot: %p", isRobot);
}
