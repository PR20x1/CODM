//
//  Cheat.hpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 22/05/2025.
//

#ifndef Cheat_hpp
#define Cheat_hpp

#include <stdio.h>
#include "../lib/Hooking/JailedHook.h"

extern char* BinaryName;

class Cheats {
public:
    static bool isRecoilUpBaseEnabled;
    static bool isRecoilUpModifierEnabled;
    static bool isRecoilUpMaxEnabled;
    static bool isUAVEnabled;
    static bool isAdvUAVEnabled;
    //---------------------------------//
    
    static bool isRecoilLateralEnabled;
    static bool isRecoilLateralModifierEnabled;
    static bool isRecoilLateralMaxEnabled;
    
    static void LoadMods();
    
private:
    Cheats() { }
    
    //---------------------------------//
    
    static float RecoilUpBase(void* instance);
    static float RecoilUpModifier(void* instance);
    static float RecoilUpMaxCheat(void* instance);
    
    //---------------------------------//
    
    static float RecoilLateralCheat(void* instance);
    static float RecoilLateralModifier(void* instance);
    static float RecoilLateralMax(void* instance);
    
    //---------------------------------//
    
    static bool UAVEnabled(void *instance);
    static bool AdvancedUAVEnabled(void *instance);
};

#endif /* Cheat_hpp */
