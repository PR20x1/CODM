//
//  Aimbot.hpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 18/05/2025.
//

#ifndef Aimbot_hpp
#define Aimbot_hpp

#include <stdio.h>
#import <Foundation/Foundation.h>
#import "GameAPI.hpp"

class Aimbot  {
public:
    static void Enable();
    static void Start();
    
    // Variables statiques avec initialisation explicite
    static bool isEnabled;
    static int aim_trigger;
    static int aim_location;
    static int aim_target;
    static float tDis;
    static float tDistance;
    static float markDistance;
    static float markDis;
    static Vector3 TargetPos;
    static bool needAdjustAim;
};

#endif /* Aimbot_hpp */
