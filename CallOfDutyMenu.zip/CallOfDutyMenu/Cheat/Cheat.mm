//
//  Cheat.cpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 22/05/2025.
//

#include "Cheat.hpp"

char* BinaryName = "cod";

bool Cheats::isRecoilUpBaseEnabled              = false;
bool Cheats::isRecoilUpModifierEnabled          = false;
bool Cheats::isRecoilUpMaxEnabled               = false;
bool Cheats::isRecoilLateralEnabled             = false;
bool Cheats::isRecoilLateralModifierEnabled     = false;
bool Cheats::isRecoilLateralMaxEnabled          = false;
bool Cheats::isUAVEnabled                       = false;
bool Cheats::isAdvUAVEnabled                    = false;


float(*oldRecoilUpBase)(void* instance);
float(*oldRecoilUpModifier)(void* instance);
float(*oldRecoilUpMax)(void* instance);
float(*oldRecoilLateralBase)(void* instance);
float(*oldRecoilLateralModifier)(void* instance);
float(*oldRecoilLateralMax)(void* instance);
bool(*oldUAV)(void* instance);
bool(*oldAdvUAV)(void* instance);

float Cheats::RecoilUpBase(void* instance) {
    if(instance != nullptr){
        if (Cheats::isRecoilUpBaseEnabled) {
            return 0.0f;
        }
    }
    return oldRecoilUpBase(instance);
}

float Cheats::RecoilUpModifier(void* instance) {
    if(instance != nullptr){
        if (Cheats::isRecoilUpModifierEnabled){
            return 0.0f;
        }
    }
    return oldRecoilUpModifier(instance);
}

float Cheats::RecoilUpMaxCheat(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilUpMaxEnabled) {
            return 0.0f;
        }
    }
    return oldRecoilUpMax(instance);
}

//---------------------------------//

float Cheats::RecoilLateralCheat(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilLateralEnabled) {
            return 0.0F;
        }
    }
    return oldRecoilLateralBase(instance);
}

float Cheats::RecoilLateralModifier(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilLateralModifierEnabled) {
            return 0.0F;
        }
    }
    return oldRecoilLateralModifier(instance);
}

float Cheats::RecoilLateralMax(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilLateralMaxEnabled) {
            return 0.0F;
        }
    }
    return oldRecoilLateralMax(instance);
}

bool Cheats::UAVEnabled(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isUAVEnabled)
        {
            return true;
        }
    }
    return oldUAV(instance);
}

bool Cheats::AdvancedUAVEnabled(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isAdvUAVEnabled)
        {
            return true;
        }
    }
    return oldAdvUAV(instance);
}


void Cheats::LoadMods() {
    HOOK(0x23AF2DC, Cheats::RecoilUpBase, oldRecoilUpBase);
    HOOK(0x23AFAF0, Cheats::RecoilUpModifier, oldRecoilUpModifier);
    HOOK(0x23B1AA8, Cheats::RecoilUpMaxCheat, oldRecoilUpMax);
    
    HOOK(0x23AF6E8, Cheats::RecoilLateralCheat, oldRecoilLateralBase);
    HOOK(0x23AFEF4, Cheats::RecoilLateralModifier, oldRecoilLateralModifier);
    HOOK(0x23B1EB0, Cheats::RecoilLateralMax, oldRecoilLateralMax);
    
    HOOK(0x1F01154, Cheats::UAVEnabled, oldUAV);
    HOOK(0x1F016D8, Cheats::AdvancedUAVEnabled, oldAdvUAV);
}

