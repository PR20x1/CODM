#ifndef JAILEDHOOK_H
#define JAILEDHOOK_H

#include "../Dobby/dobby_defines.h"
#include "../SCLAlertView/SCLAlertView.h"
#include <libgen.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach-o/dyld.h>
#include <mach/vm_page_size.h>
#import <Foundation/Foundation.h>
#include <map>
#include <deque>
#include <vector>
#include <array>

//#ifdef DEBUG
//#define log(...) NSLog(__VA_ARGS__)
//#else
//#define log(...)
//#endif

#ifdef __cplusplus
extern "C"
{
#endif

    NSString *StaticInlineHookPatch(
        char *machoPath,
        uint64_t vaddr,
        char *patch
    );

    void *StaticInlineHookFunction(
        char *machoPath,
        uint64_t vaddr,
        void *replacement
    );

    void *find_module_by_path(char *machoPath);
    BOOL DeactiveCodePatch(char *machoPath, uint64_t vaddr, char *patch);
    BOOL ActiveCodePatch(char *machoPath, uint64_t vaddr, char *patch);
    extern char *BinaryName;

#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16)) / 255.0 green:((float)((hexColor & 0xFF00) >> 8)) / 255.0 blue:((float)(hexColor & 0xFF)) / 255.0 alpha:1.0]

#define HOOK(address, hook_func, original_func)                              \
    {                                                                         \
        NSString *hook_result = StaticInlineHookPatch(BinaryName, address, nullptr); \
        if (hook_result)                                                      \
        {                                                                     \
            NSLog(@"[HOOK]: Résultat %s", hook_result.UTF8String);            \
            void *orig_ptr = StaticInlineHookFunction(BinaryName, address, (void *)hook_func); \
            NSLog(@"[HOOK]: Fonction originale à %p", orig_ptr);              \
            *(void **)(&original_func) = (void *)orig_ptr;                   \
        }                                                                     \
        else                                                                  \
        {                                                                     \
            NSLog(@"[HOOK]: Échec d'installation du hook à l'adresse %p", (void*)address); \
        }                                                                     \
    }

#define HOOKPTR(x, z)                                                     \
    NSString *result_##z = StaticInlineHookPatch(BinaryName, x, nullptr); \
    if (result_##z)                                                       \
    {                                                                     \
        log(@"Hook result: %s", result_##z.UTF8String);                   \
    }

#define PATCHOFFSET(x, z, active)                                                                            \
    {                                                                                                        \
        log(@"Attempting patch #%llx", x);                                                                   \
        NSString *result_patch_##x = StaticInlineHookPatch(BinaryName, x, z);                                \
        if (result_patch_##x)                                                                                \
        {                                                                                                    \
            log(@"Hook result for %llx: %s", x, [result_patch_##x UTF8String]);                              \
            BOOL success = active ? ActiveCodePatch(BinaryName, x, z) : DeactiveCodePatch(BinaryName, x, z); \
            log(@"Patch %s result for %llx: %d", active ? "activation" : "deactivation", x, success);        \
        }                                                                                                    \
    }

#ifdef __cplusplus
}
#endif

#endif // JAILEDHOOK_H
