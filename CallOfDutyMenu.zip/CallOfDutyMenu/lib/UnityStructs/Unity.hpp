#include <mach-o/dyld.h>
#include <string>
#include <map>

#import <Foundation/Foundation.h>

template <typename T>
struct monoArray
{
    void* klass;
    void* monitor;
    void* bounds;
    int   max_length;
    T vector [0];
    int getLength()
    {
        return max_length;
    }
    T *getPointer()
    {
        return vector;
    }
    template<typename V = T>
    std::vector<V> toCPPlist() {
        std::vector<V> ret;
        for (int i = 0; i < max_length; i++)
            ret.push_back(vector[i]);
        return std::move(ret);
    }
};
typedef struct _monoString
{
    void* klass;
    void* monitor;
    int length;    
    char chars[1];   
    int getLength()
    {
      return length;
    }
    char* getChars()
    {
        return chars;
    }
    NSString* toNSString()
    {
      return [[NSString alloc] initWithBytes:(const void *)(chars)
                     length:(NSUInteger)(length * 2)
                     encoding:(NSStringEncoding)NSUTF16LittleEndianStringEncoding];
    }
    char* toCString()
    {
      NSString* v1 = toNSString();
      return (char*)([v1 UTF8String]);  
    }
    std::string toCPPString()
    {
      return std::string(toCString());
    }
}monoString;
template <typename T>
struct monoList {
	void *unk0;
	void *unk1;
	monoArray<T> *items;
	int size;
	int version;
	T *getItems(){
		return items->getPointer();
	}
	int getSize(){
		return size;
	}
	int getVersion(){
		return version;
	}
};
template <typename K, typename V>
struct monoDictionary {
	void *unk0;
	void *unk1;
	monoArray<int **> *table;
	monoArray<void **> *linkSlots;
	monoArray<K> *keys;
	monoArray<V> *values;
	int touchedSlots;
	int emptySlot;
	int size;
	K getKeys(){
		return keys->getPointer();
	}
	V getValues(){
		return values->getPointer();
	}
	int getNumKeys(){
		return keys->getLength();
	}
	int getNumValues(){
		return values->getLength();
	}
	int getSize(){
		return size;
	}
};
template<typename TKey, typename TValue>
    struct monoDictionary2 {
        struct Entry {
            int hashCode, next;
            TKey key;
            TValue value;
        };
        void *klass;
        void *monitor;
        monoArray<int> *buckets;
        monoArray<Entry> *entries;
        int count;
        int version;
        int freeList;
        int freeCount;
        void *comparer;
        monoArray<TKey> *keys;
        monoArray<TValue> *values;
        void *syncRoot;
        std::map<TKey, TValue> toMap() {
            std::map<TKey, TValue> ret;
            auto lst = entries->toCPPlist();
            for (auto enter : lst)
                ret.insert(std::make_pair(enter.key, enter.value));
            return std::move(ret);
        }
        std::vector<TKey> getKeys() {
            std::vector<TKey> ret;
            auto lst = entries->toCPPlist();
            for (auto enter : lst)
                ret.push_back(enter.key);
            return std::move(ret);
        }
        std::vector<TValue> getValues() {
            std::vector<TValue> ret;
            auto lst = entries->toCPPlist();
            for (auto enter : lst)
                ret.push_back(enter.value);
            return std::move(ret);
        }
        int getSize() {
            return count;
        }
        int getVersion() {
            return version;
        }
        bool TryGet(TKey key, TValue &value);
        void Add(TKey key, TValue value);
        void Insert(TKey key, TValue value);
        bool Remove(TKey key);
        bool ContainsKey(TKey key);
        bool ContainsValue(TValue value);
        TValue Get(TKey key) {
            TValue ret;
            if (TryGet(key, ret))
                return ret;
            return {};
        }
        TValue operator [](TKey key) {
            return Get(key);
        }
    };
#if 0
template<typename T>
monoArray<T> *CreateNativeCSharpArray(int startingLength){
	monoArray<T> *(*IL2CPPArray_Create)(void *klass, int startingLength) = (monoArray<T> *(*)(void *, int))getRealOffset(/*FIRST LOCATION HERE*/);
	void *unkptr0 = *(void **)(ASLR_BIAS + );
	void *klass = *(void **)((uint64_t)unkptr0);
	monoArray<T> *arr = IL2CPPArray_Create(klass, startingLength);
	return arr;
}
#endif
union intfloat {
	int i;
	float f;
};
inline int GetObscuredIntValue(uint64_t location){
	int cryptoKey = *(int *)location;
	int obfuscatedValue = *(int *)(location + 0x4);
	return obfuscatedValue ^ cryptoKey;
}
inline void SetObscuredIntValue(uint64_t location, int value){
	int cryptoKey = *(int *)location;
	
	*(int *)(location + 0x4) = value ^ cryptoKey;
}
inline float GetObscuredFloatValue(uint64_t location){
	int cryptoKey = *(int *)location;
	int obfuscatedValue = *(int *)(location + 0x4);
	intfloat IF;
	IF.i = obfuscatedValue ^ cryptoKey;
	return IF.f;
}
inline void SetObscuredFloatValue(uint64_t location, float value){
	int cryptoKey = *(int *)location;
	intfloat IF;
	IF.f = value;
	intfloat IF2;
	IF2.i = IF.i ^ cryptoKey;
	*(float *)(location + 0x4) = IF2.f;
}
inline Vector3 GetObscuredVector3Value(uint64_t location){
	int cryptoKey = *(int *)location;
	Vector3 ret;
	intfloat IF;
	IF.i = *(int *)(location + 0x4) ^ cryptoKey;
	ret.x = IF.f;
	IF.i = *(int *)(location + 0x8) ^ cryptoKey;
	ret.y = IF.f;
	IF.i = *(int *)(location + 0xc) ^ cryptoKey;
	ret.z = IF.f;
	return ret;
}
inline void SetObscuredVector3Value(uint64_t location, Vector3 value){
	int cryptoKey = *(int *)location;
	intfloat IF;
	IF.f = value.x;
	intfloat IF2;
	IF2.i = IF.i ^ cryptoKey;
	*(float *)(location + 0x4) = IF2.f;
	IF.f = value.y;
	IF2.i = IF.i ^ cryptoKey;
	*(float *)(location + 0x8) = IF2.f;
	IF.f = value.z;
	IF2.i = IF.i ^ cryptoKey;
	*(float *)(location + 0xc) = IF2.f;
}
struct Color {
    union {
        struct {
            float r, b, g, a;
        };
        float data[4];
    };
    Color() {
        SetColor(0, 0, 0, 255);
    }
    Color(float r, float g, float b) {
        SetColor(r, g, b, 255);
    }
    Color(float r, float g, float b, float a) {
        SetColor(r, g, b, a);
    }
    void SetColor(float r1, float g1, float b1, float a1 = 255) {
        r = r1;
        g = g1;
        b = b1;
        a = a1;
    }
    static Color Black(float a = 255) { return Color(0, 0, 0, a); }
    static Color Red(float a = 255) { return Color(255, 0, 0, a); }
    static Color Green(float a = 255) { return Color(0, 255, 0, a); }
    static Color Blue(float a = 255) { return Color(0, 0, 255, a); }
    static Color White(float a = 255) { return Color(255, 255, 255, a); }
    static Color Orange(float a = 255) { return Color(255, 153, 0, a); }
    static Color Yellow(float a = 255) { return Color(255, 255, 0, a); }
    static Color Cyan(float a = 255) { return Color(0, 255, 255, a); }
    static Color Magenta(float a = 255) { return Color(255, 0, 255, a); }
    static Color MonoBlack(float a = 1){ return Color(0, 0, 0, a); }
    static Color MonoRed(float a = 1){ return Color(1, 0, 0, a); }
    static Color MonoGreen(float a = 1){ return Color(0, 1, 0, a); }
    static Color MonoBlue(float a = 1){ return Color(0, 0, 1, a); }
    static Color MonoWhite(float a = 1){ return Color(1, 1, 1, a); }
    static Color MonoOrange(float a = 1){ return Color(1, 0.55, 0, a); }
    static Color MonoYellow(float a = 1){ return Color(1, 1, 0, a); }
    static Color MonoCyan(float a = 1){ return Color(0, 1, 1, a); }
    static Color MonoMagenta(float a = 1){ return Color(1, 0, 1, a); }
    static Color random(float a = 255) {
        float r = static_cast <float> (rand()) / static_cast <float> (255);
        float g = static_cast <float> (rand()) / static_cast <float> (255);
        float b = static_cast <float> (rand()) / static_cast <float> (255);
        return Color(r, g, b, a);
    }
    Color invert(int a = 255){
        return Color(255 - r, 255 - g, 255 - b, a);
    }
};
