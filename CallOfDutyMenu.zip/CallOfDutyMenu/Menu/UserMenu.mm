#include "UserMenu.h"
#include "../Utilities/Memory.h"
#include "../Cheat/Aimbot.hpp"
#include "../Cheat/GameAPI.hpp"
#include "../Cheat/ESP.hpp"
#include "../Cheat/CheatState.hpp"
#include "../Cheat/Cheat.hpp"

void SetCustomImGuiStyle()
{
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    // Fond principal
    colors[ImGuiCol_WindowBg]           = ImVec4(0.10f, 0.12f, 0.13f, 1.00f);
    colors[ImGuiCol_ChildBg]            = ImVec4(0.12f, 0.14f, 0.16f, 1.00f);

    // Barres, tabs, header
    colors[ImGuiCol_Header]             = ImVec4(0.16f, 0.20f, 0.18f, 1.00f);
    colors[ImGuiCol_HeaderHovered]      = ImVec4(0.20f, 0.28f, 0.20f, 1.00f);
    colors[ImGuiCol_HeaderActive]       = ImVec4(0.18f, 0.25f, 0.18f, 1.00f);

    // Tabs
    colors[ImGuiCol_Tab]                = ImVec4(0.13f, 0.16f, 0.13f, 1.00f);
    colors[ImGuiCol_TabHovered]         = ImVec4(0.20f, 0.28f, 0.20f, 1.00f);
    colors[ImGuiCol_TabActive]          = ImVec4(0.18f, 0.25f, 0.18f, 1.00f);

    // Boutons
    colors[ImGuiCol_Button]             = ImVec4(0.13f, 0.18f, 0.13f, 1.00f);
    colors[ImGuiCol_ButtonHovered]      = ImVec4(0.20f, 0.35f, 0.20f, 1.00f);
    colors[ImGuiCol_ButtonActive]       = ImVec4(0.18f, 0.30f, 0.18f, 1.00f);

    // Sliders, checks, etc.
    colors[ImGuiCol_FrameBg]            = ImVec4(0.13f, 0.16f, 0.13f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]     = ImVec4(0.20f, 0.28f, 0.20f, 1.00f);
    colors[ImGuiCol_FrameBgActive]      = ImVec4(0.18f, 0.25f, 0.18f, 1.00f);

    // Accents verts
    ImVec4 accent = ImVec4(0.20f, 0.85f, 0.40f, 1.00f);
    colors[ImGuiCol_CheckMark]          = accent;
    colors[ImGuiCol_SliderGrab]         = accent;
    colors[ImGuiCol_SliderGrabActive]   = ImVec4(0.25f, 1.00f, 0.50f, 1.00f);
    colors[ImGuiCol_ButtonHovered]      = accent;
    colors[ImGuiCol_ButtonActive]       = ImVec4(0.15f, 0.60f, 0.25f, 1.00f);

    // Textes
    colors[ImGuiCol_Text]               = ImVec4(0.90f, 0.95f, 0.90f, 1.00f);
    colors[ImGuiCol_TextDisabled]       = ImVec4(0.50f, 0.55f, 0.50f, 1.00f);

    // Autres
    colors[ImGuiCol_Border]             = ImVec4(0.18f, 0.22f, 0.18f, 1.00f);

    // Style général
    style.WindowRounding    = 8.0f;
    style.FrameRounding     = 6.0f;
    style.GrabRounding      = 6.0f;
    style.ScrollbarRounding = 8.0f;
    style.TabRounding       = 6.0f;
    style.ChildRounding     = 8.0f;
    style.PopupRounding     = 8.0f;
    style.FramePadding      = ImVec2(10, 6);
    style.ItemSpacing       = ImVec2(10, 8);
    style.WindowPadding     = ImVec2(12, 12);
}

void UserMenu::RenderMenu()
{
    ImGui::SetNextWindowPos(ImVec2((SCREEN_WIDTH - 390) - 0, 0), ImGuiCond_Once);
    ImGui::SetNextWindowSize(ImVec2(390, 370), ImGuiCond_Once);

    SetCustomImGuiStyle();

    ImGui::Begin("Tool", NULL, ImGuiWindowFlags_NoCollapse);

    settings.MenuSize = ImGui::GetCurrentWindow()->Size;
    settings.MenuPos  = ImGui::GetCurrentWindow()->Pos;

    if (ImGui::Button("Save Settings"))
        settings.Save();

    if (ImGui::BeginTabBar("TabBar")) {
        // Aimbot Tab
        if (ImGui::BeginTabItem("Aimbot")) {
            ImGui::Spacing();
            
            // Section principale de l'Aimbot
            ImGui::Checkbox("Enable Aimbot", &Aimbot::isEnabled);
            
            if (Aimbot::isEnabled) {
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();
                
                // Configuration du ciblage
                ImGui::Text("Target Settings");
                ImGui::Combo("Target Selection", &Aimbot::aim_target, "Closest\0Inside FOV\0");
                ImGui::Combo("Aim Location", &Aimbot::aim_location, "Head\0Chest\0Legs\0");
                ImGui::Combo("Activation", &Aimbot::aim_trigger, "Always\0Firing\0Aiming\0");
                
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();
                
                // Configuration du FOV
                ImGui::Text("FOV Settings");
                ImGui::Checkbox("Show FOV Circle", &CheatState::enable_circleFov);
                if (CheatState::enable_circleFov) {
                    ImGui::SliderFloat("FOV Size", &GameAPI::FOVCircleSize, 50.0f, 300.0f, "%.0f");
                    
                    static float circleColor[4] = {1.0f, 0.0f, 0.0f, 1.0f};
                    if (ImGui::ColorEdit4("FOV Color", circleColor, ImGuiColorEditFlags_NoInputs)) {
                        GameAPI::SetFOVCircleColor(ImVec4(circleColor[0], circleColor[1], circleColor[2], circleColor[3]));
                    }
                }
                
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();
                
                // Informations de débogage
                ImGui::Text("Debug Info");
                ImGui::Text("Target Distance: %.1f", Aimbot::tDistance);
                ImGui::Text("Target Selected: %s", Aimbot::needAdjustAim ? "Yes" : "No");
            }
            
            ImGui::EndTabItem();
        }

        // ESP Tab
        if (ImGui::BeginTabItem("ESP")) {
            ImGui::Spacing();
            
            ImGui::Checkbox("Enable ESP", &ESP::isEnabled);
            if (ESP::isEnabled) {
                ImGui::Separator();
                ImGui::Checkbox("ESP - Lines", &ESP::show_lines);
                ImGui::Checkbox("ESP - Boxes", &ESP::show_boxes);
                ImGui::Checkbox("ESP - Info", &ESP::show_info);
                ImGui::Separator();
                ImGui::SliderInt("ESP - Distance", &ESP::distance_value, 0, 200);
                ImGui::Spacing();
                
                if (ImGui::ColorEdit4("ESP Color", ESP::color, ImGuiColorEditFlags_NoInputs)) {
                    // La couleur est déjà mise à jour directement dans le tableau ESP::color
                }
            }
            
            ImGui::EndTabItem();
        }
        
        // UAV Tab
        if (ImGui::BeginTabItem("UAV")) {
            ImGui::Spacing();
            
            bool previousUAVState = Cheats::isUAVEnabled;
            if (ImGui::Checkbox("Enable UAV Cheats", &Cheats::isUAVEnabled)) {
                if (previousUAVState != Cheats::isUAVEnabled) {
                    Cheats::LoadMods();
                }
            }
            
            if (Cheats::isUAVEnabled) {
                ImGui::Separator();
                
                bool previousAdvUAVState = Cheats::isAdvUAVEnabled;
                if (ImGui::Checkbox("Advanced UAV", &Cheats::isAdvUAVEnabled)) {
                    if (previousAdvUAVState != Cheats::isAdvUAVEnabled) {
                        Cheats::LoadMods();
                    }
                }
            }
            
            ImGui::EndTabItem();
        }

        // Recoil Tab
        if (ImGui::BeginTabItem("Recoil")) {
            ImGui::Spacing();
            
            // Vertical Recoil Controls
            ImGui::Text("Vertical Recoil");
            ImGui::Separator();
            if (ImGui::Checkbox("No Recoil Up Base", &Cheats::isRecoilUpBaseEnabled)) {
                Cheats::LoadMods();
            }

            if (ImGui::Checkbox("No Recoil Up Modifier", &Cheats::isRecoilUpModifierEnabled)) {
                Cheats::LoadMods();
            }

            if (ImGui::Checkbox("No Recoil Up Max", &Cheats::isRecoilUpMaxEnabled)) {
                Cheats::LoadMods();
            }
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            
            // Lateral Recoil Controls
            ImGui::Text("Lateral Recoil");
            ImGui::Separator();
            if (ImGui::Checkbox("No Recoil Lateral Base", &Cheats::isRecoilLateralEnabled)) {
                Cheats::LoadMods();
            }

            if (ImGui::Checkbox("No Recoil Lateral Modifier", &Cheats::isRecoilLateralModifierEnabled)) {
                Cheats::LoadMods();
            }

            if (ImGui::Checkbox("No Recoil Lateral Max", &Cheats::isRecoilLateralMaxEnabled)) {
                Cheats::LoadMods();
            }
            
            ImGui::EndTabItem();
        }

        // Misc Tab
        if (ImGui::BeginTabItem("Misc")) {
            ImGui::SliderInt("Draw Refresh Rate", &settings.DrawRefreshRate, 10, 120);
            ImGui::EndTabItem();
        }
        
        ImGui::EndTabBar();   
    }
    
    ImGui::End();
}
