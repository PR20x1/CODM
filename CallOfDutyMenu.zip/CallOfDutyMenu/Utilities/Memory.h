#pragma once

#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/mach.h>
#include <mach/mach_init.h>
#include <mach/vm_map.h>
#include <type_traits> 
#include <utility>    
#include "Singleton.h"

typedef int8_t int8;
typedef int16_t int16;
typedef int32_t int32;
typedef int64_t int64;
typedef intptr_t intptr;
typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef uint64_t uint64;
typedef uintptr_t uintptr;

typedef struct {
    mach_msg_header_t Head;
    NDR_record_t NDR;
    mach_vm_address_t address;
    mach_vm_size_t size;
    boolean_t set_maximum;
    vm_prot_t new_protection;
} __Request__mach_vm_protect_t;

class memory_t
{
public:
    struct mach_header_64* get_header(const char* header_name) const
    {
        static struct mach_header_64* header = 0;
        if (header != nullptr)
            return header;
            
        for (uint32_t i = 0; i < _dyld_image_count(); ++i) 
        {
            const char* image_path = _dyld_get_image_name(i);
            if (__builtin_strstr(image_path, header_name)) 
            {
                header = (struct mach_header_64*)_dyld_get_image_header(i);
                break;
            }
        }
        return header;
    }

    intptr_t get_aslr_rebase(const char* name) const 
    {
        for (uint32_t i = 0; i < _dyld_image_count(); ++i) 
        {
            const char* image_path = _dyld_get_image_name(i);
            if (__builtin_strstr(image_path, name)) 
            {
                return _dyld_get_image_vmaddr_slide(i);
            }
        }
        return 0;
    }
    
    uintptr_t get_address(uint64_t offset) const
    {
        return get_aslr_rebase("codmvn") + offset;
    }

    template<typename type> 
	type read(uintptr_t address) 
    {
	    type read_data;
	    read_impl(address, reinterpret_cast<void *>(&read_data), sizeof(type));
	    return read_data;
	}

	template<typename type> 
	void write(uintptr_t address, type data) 
    {
	    write_impl(address, reinterpret_cast<void *>(&data), sizeof(type));
	}

    bool is_valid(uintptr ptr) const 
    {
        return ptr && ptr % 8 != 0;
    }
    
    void protect_overwrite(mach_vm_address_t address, mach_vm_size_t size, vm_prot_t new_prot) const
    {
        kern_return_t kr;
        mach_port_t self_task = mach_task_self();

        __Request__mach_vm_protect_t request = {};
        struct {
            mach_msg_header_t header;
            NDR_record_t ndr;
            kern_return_t ret_code;
        } reply = {};

        request.Head.msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, MACH_MSG_TYPE_MAKE_SEND_ONCE);
        request.Head.msgh_size = sizeof(request);
        request.Head.msgh_remote_port = self_task;
        request.Head.msgh_local_port = mig_get_reply_port();
        request.Head.msgh_id = 4802;

        request.NDR = NDR_record;
        request.address = address;
        request.size = size;
        request.set_maximum = 0;
        request.new_protection = new_prot;

        kr = mach_msg(&request.Head, MACH_SEND_MSG | MACH_RCV_MSG, sizeof(request), sizeof(reply),
                      request.Head.msgh_local_port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    }
    
    
private:
    bool read_impl(long Address, void *buffer, int len)
    {
        if ( !is_valid(Address) ) 
            return false;

        vm_size_t size = 0;
        kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)Address, len, (vm_address_t)buffer, &size);
        return error == KERN_SUCCESS && size == len;
    }

    bool write_impl(long Address, void *buffer, int len)
    {
        if ( !is_valid(Address) ) 
            return false;

        kern_return_t error = vm_write(mach_task_self(), (vm_address_t)Address, (vm_offset_t)buffer, (mach_msg_type_number_t)len);
        return error == KERN_SUCCESS;
    }
};


