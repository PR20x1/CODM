#ifndef MemoryManager_hpp
#define MemoryManager_hpp

#include "Memory.h"

class MemoryManager : public Singleton<MemoryManager> {
public:
    static memory_t& GetMemory() {
        static memory_t instance;
        return instance;
    }
};

#endif /* MemoryManager_hpp */ 