#pragma once

#include <string>
#include "imgui.h"
#include "Singleton.h"
#include "Macros.h"

#include <mach-o/dyld.h>
#include <mach/mach.h>
#include <iostream>
#include <filesystem>
#include <fstream>

class Settings : public Singleton<Settings> 
{
public:
    ImVec2 MenuSize;
    ImVec2 MenuPos;

    float FOV = 90.0f;

    bool StreamerMode = false;
    
    int DrawRefreshRate = 60;

    void Save() 
    {
        static std::filesystem::path FilePath = GetDocumentsPath() / "Settings.txt";

        std::ofstream OutFile(FilePath, std::ios::binary | std::ios::trunc);
        OutFile.write(reinterpret_cast<const char*>(this), sizeof(Settings));
        OutFile.close();
    }

    void Load() 
    {
        static std::filesystem::path FilePath = GetDocumentsPath() / "Settings.txt";

        if (std::filesystem::exists(FilePath)) 
        {
            std::ifstream InFile(FilePath, std::ios::binary);
            InFile.read(reinterpret_cast<char*>(this), sizeof(Settings));
            InFile.close();
        }
    }
    
private:
    friend class Singleton<Settings>;
    Settings() { };

    ~Settings() { };
    

    std::filesystem::path GetDocumentsPath()
    {
        @autoreleasepool 
        {
            NSArray* Paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            NSString* DocumentsPath = [Paths firstObject];
            return std::filesystem::path([DocumentsPath UTF8String]);
        }
    }
};
